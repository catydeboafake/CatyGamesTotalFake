label comecolojinha:
    $ copo = " "
    $ decoracao = " "
    $ sabor = ""
    C "Então vamos, nós temos mais opções de cupcake!!"
    C "E depois disso terá clientes"
    C "Então se {b}prepara{/b}"
    menu:
        "Criar outro cupcake":
            jump cuptestinho
        "Abrir logo a loja":
            jump abrindo


label cuptestinho:
    menu:
        "qual copo?"
        "vermelho":
            $ copo = "redcup"
        "verde":
            $ copo = "greencup"
        "padrão":
            $ copo = "cup"
    
    show expression f"cupcake {copo} {sabor} {decoracao}" 

    menu:
        "qual recheio?"
        "choco":
            $ sabor = "choco"  
        "morango":
            $ sabor = "morango"
        "mirtilo":
            $ sabor = "mirtilo"
        "pera":
            $ sabor = "pera"
        "oreo":
            $ sabor = "oreo"
        "creme":
            $ sabor = "creme"
        "laranja":
            $ sabor = "laranja"

    show expression f"cupcake {copo} {sabor} {decoracao}"

    menu:
        "qual decoração?"
        "coração":
            $ decoracao = "heart"
        "colorido":
            $ decoracao = "rainbow"
        "estrelas":
            $ decoracao = "stars"
    
    show expression f"cupcake {copo} {sabor} {decoracao}"
    "bora cumer?"
    hide cupcake
    show expression f"cupcake {copo} {sabor} {decoracao}"
    $ renpy.pause(1.0)
    hide cupcake
    show expression f"cupcake {copo} {sabor} {decoracao}":
        zoom 2
    $ renpy.pause(1.0)
    hide expression f"cupcake {copo} {sabor} {decoracao}"
    "tu" "yumi!"
    C "Acho que a gente já pode abrir a loja"
    jump catycliente
    




label catycliente:
    C "Sabe quem vai ser seu primeiro cliente?"
    show Ca Normal with dissolve
    C "{b}EU!!{/b}"
    C "Eu vou querer um bem simples.."
    C "Copinho padrão{w}, sabor chocolate{w}, e estrelinhas!"
    call cozinhar
    $ erros = []
    if copo != "cup":
        $ erros.append("o copo")
    if sabor != "choco":
        $ erros.append("o sabor")
    if decoracao != "stars":
        $ erros.append("a decoração")
    
    if len(erros) == 0:
        "Tudo certo!"
    elif len(erros) == 1:
        $ msg = "só {} que está errado".format(erros[0])
        "[msg]"
        "foi quase! você deve ter confundido"
        "vamos de novo.."
        jump catycliente
    elif len(erros) == 2:
        $ msg = "você errou os dois.. {} e {}..".format(erros[0], erros[1])
        "[msg]"
        "não sei se você ta muito pronto, vamos tentar de novo!"
        jump catycliente
    elif len(erros) == 3:
        $ msg = "você errou os três, mas não tem problema.. foi nervossísmo?".format(erros[0], erros[1])
        "[msg]"
        "Vamos começar de novo, você consegue!"
        jump catycliente
        
    
    return