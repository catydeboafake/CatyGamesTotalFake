﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.
$ sabor = " "
$ decoracao = " "
$ copo = " "

$ erros = []

$ NomeLoja = "semnomelol"

define C = Character("Catyzita", color='#cd47ee') 
image Ca Normal = "images/caty/Normal1.png"
define Y = Character("Criadora de [NomeLoja]")

image fundo = "images/fundo.png"
image cup = "images/cup.png"
image choco = "images/choco.png"
image morango = "images/morango.png"
image heart = "images/heart.png"
image rainbow = "images/rainbow.png"




layeredimage cupcake:
    group cup:
        attribute cup:
            "images/cup.png"
        attribute greencup:
            "images/greencup.png"
        attribute redcup:
            "images/redcup.png"
    group sabor:
        attribute choco:
            "images/choco.png"
        attribute morango:
            "images/morango.png"
        attribute pera:
            "images/pera.png"
        attribute oreo:
            "images/oreo.png"
        attribute mirtilo:
            "images/mirtilo.png"
        attribute laranja:
            "images/laranja.png"
        attribute creme:
            "images/creme.png"

    group decoracao:
        attribute heart:
            "images/heart.png"
        attribute rainbow:
            "images/rainbow.png"
        attribute stars:
            "images/stars.png"






# The game starts here.

label start:
    show fundo
    menu:
        "começar?"
        "sim":
            jump comecou
        "teste":
            jump teste
    return

label comecou:
    show cupcake cup
    menu:
        "qual recheio?"
        "choco":
            $ sabor = "choco"
            show cupcake cup choco
        "morango":
            $ sabor = "morango"
            show cupcake cup morango
    "omaga!!"
    "admire.."
    $ renpy.pause(10)
    menu:
        "qual decoração?"
        "coração":
            $ decoracao = "heart"
            show cupcake cup  heart
        "colorido":
            $ decoracao = "rainbow"
            show cupcake cup  rainbow
    "bora cumer?"
    hide cupcake
    show expression f"cupcake cup {sabor} {decoracao}"
    $ renpy.pause(1.0)
    hide cupcake
    show expression f"cupcake cup {sabor} {decoracao}":
        zoom 2
    $ renpy.pause(1.0)
    hide expression f"cupcake cup {sabor} {decoracao}"
    "tu" "yumi!"
    "ei.."
    "Você agora precisa de um nome.."
    "PARA SUA LOJA!!"
    $ NomeLoja = renpy.input("Pense em um nome muiiito legal!!!", length = 32)
    "Nossa!! que nome incrível"
    "Você é a criadora de [NomeLoja] apartir de agora"
    "Vamos lá e [NomeLoja] sera o melhor restaurante de todos!!"
    Y "Legal!!"
    C "Alias, meu nome é Catyzita!"
    jump comecolojinha

    