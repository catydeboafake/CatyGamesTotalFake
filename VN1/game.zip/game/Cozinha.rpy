label cozinhar:
    menu:
        "qual copo?"
        "vermelho":
            $ copo = "redcup"
        "verde":
            $ copo = "greencup"
        "padrão":
            $ copo = "cup"
    
    show expression f"cupcake {copo} " 

    menu:
        "qual recheio?"
        "choco":
            $ sabor = "choco"  
        "morango":
            $ sabor = "morango"
        "mirtilo":
            $ sabor = "mirtilo"
        "pera":
            $ sabor = "pera"
        "oreo":
            $ sabor = "oreo"
        "creme":
            $ sabor = "creme"
        "laranja":
            $ sabor = "laranja"

    show expression f"cupcake {copo} {sabor}"

    menu:
        "qual decoração?"
        "coração":
            $ decoracao = "heart"
        "colorido":
            $ decoracao = "rainbow"
        "estrelas":
            $ decoracao = "stars"
    
    show expression f"cupcake {copo} {sabor} {decoracao}"

    return