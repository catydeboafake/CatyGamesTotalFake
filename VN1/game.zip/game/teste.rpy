label teste:
    menu:
        "fazer bolinho e voltar":
            "wait"
            call cozinhar
            "[sabor], [copo], [decoracao]"
            "neh?"
    return